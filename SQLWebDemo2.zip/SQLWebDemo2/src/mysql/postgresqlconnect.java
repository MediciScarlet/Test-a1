package mysql;

import java.sql.*;
import java.util.*;

public class postgresqlconnect {
	
	public static ArrayList<Map<String, String>> getScoreInfo (String courseName) { 
	
	Connection conn = null;

	Statement stat = null;

	ArrayList<Map<String, String>> arrayList = new ArrayList<>(); 
	try {

		Class.forName("org.postgresql.Driver");

		String url = "jdbc:postgresql://localhost:5432/gradedb";

		String username = "postgres";

		String password = "Hyf200178#";

		conn = DriverManager.getConnection(url, username, password); String sql = "SELECT * FROM course_student_score_view"; stat = conn.createStatement();

		ResultSet result = stat.executeQuery(sql);

		while (result.next()) {

				String getCourseName = result.getString("�γ�����");

				if (getCourseName.equals(courseName)) {

					float scoreDouble = result.getFloat("����");

					String score = Float.toString(scoreDouble);
	
					Map<String, String> map = new HashMap<>();

					map.put("ѧ������", result.getString("ѧ������"));

					map.put("����", score);


					arrayList.add(map);

				}

		}

	}catch (Exception e) { e.printStackTrace();
	}finally {

	try {

		if (stat != null) {

			stat.close();

		}

	}catch (SQLException e) { e.printStackTrace();}

	try {

		if (conn != null) {

			conn.close();

		}

	}catch (SQLException e) {

		e.printStackTrace();

	}

	}

	return arrayList;

	}
}
